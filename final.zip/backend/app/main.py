import json
from collections import Counter
from pathlib import Path
from typing import Annotated

from fastapi import Depends, FastAPI, File, Form, HTTPException, Query, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.database import Base, engine, get_db
from app.models import AnalysisRecord
from app.schemas import AnalysisInput, AnalysisResult, DashboardResponse, DemoCase, ModelInfo, UrlCheck
from app.services.analysis import analyze_content
from app.services.classifier import model_metrics
from app.services.extraction import extract_upload
from app.services.urls import inspect_url

settings = get_settings()
Base.metadata.create_all(bind=engine)
app = FastAPI(
    title="ScamShield API",
    description="Explainable, multi-signal scam risk analysis for student-facing messages and links. Results are indicators, not verdicts.",
    version="1.0.0",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[origin.strip() for origin in settings.cors_origins.split(",") if origin.strip()],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type"],
)

DEMO_PATH = Path(__file__).resolve().parent / "data" / "demo_cases.json"


def _save_summary(db: Session, result: AnalysisResult) -> None:
    record = AnalysisRecord(
        id=result.id,
        created_at=result.created_at,
        category=result.category,
        source=result.source,
        risk_level=result.risk_level.value,
        risk_score=result.risk_score,
        summary=result.summary,
        evidence_count=len(result.evidence),
        pattern_keys=json.dumps([item.key for item in result.evidence]),
    )
    db.add(record)
    db.commit()


@app.get("/api/health", tags=["system"])
def health() -> dict[str, str]:
    return {"status": "ok", "service": "ScamShield API"}


@app.post("/api/analyze", response_model=AnalysisResult, tags=["analysis"])
def analyze(request: AnalysisInput, db: Annotated[Session, Depends(get_db)]) -> AnalysisResult:
    if not request.text.strip():
        raise HTTPException(status_code=422, detail="Enter a message or URL to analyze.")
    result = analyze_content(request)
    _save_summary(db, result)
    return result


@app.post("/api/analyze/upload", response_model=AnalysisResult, tags=["analysis"])
async def analyze_upload(
    db: Annotated[Session, Depends(get_db)],
    file: Annotated[UploadFile, File(...)],
    category: Annotated[str, Form()] = "General",
    context: Annotated[str, Form()] = "",
) -> AnalysisResult:
    max_bytes = settings.max_upload_mb * 1024 * 1024
    extracted, source = await extract_upload(file, max_bytes)
    combined = f"{context.strip()}\n{extracted}".strip()
    result = analyze_content(
        AnalysisInput(text=combined, category=category, source=source),
        source=source,
        extracted_text=extracted,
    )
    _save_summary(db, result)
    return result


@app.get("/api/url-check", response_model=UrlCheck, tags=["analysis"])
def check_url(url: Annotated[str, Query(min_length=3, max_length=2048)]) -> UrlCheck:
    if not url.strip():
        raise HTTPException(status_code=422, detail="Provide a URL to inspect.")
    return inspect_url(url.strip())


@app.get("/api/demos", response_model=list[DemoCase], tags=["demo"])
def demo_cases() -> list[DemoCase]:
    return [DemoCase(**item) for item in json.loads(DEMO_PATH.read_text(encoding="utf-8"))]


@app.post("/api/demos/{demo_id}/analyze", response_model=AnalysisResult, tags=["demo"])
def analyze_demo(demo_id: str) -> AnalysisResult:
    case = next((item for item in json.loads(DEMO_PATH.read_text(encoding="utf-8")) if item["id"] == demo_id), None)
    if case is None:
        raise HTTPException(status_code=404, detail="Demo case not found.")
    result = analyze_content(AnalysisInput(text=case["text"], category=case["category"], source="demo"), source="demo")
    return result


@app.get("/api/model-info", response_model=ModelInfo, tags=["system"])
def get_model_info() -> ModelInfo:
    return ModelInfo(**model_metrics())


@app.get("/api/dashboard", response_model=DashboardResponse, tags=["dashboard"])
def dashboard(db: Annotated[Session, Depends(get_db)]) -> DashboardResponse:
    records = list(db.scalars(select(AnalysisRecord).order_by(AnalysisRecord.created_at.desc())))
    levels = ["High Risk", "Medium Risk", "Low Risk", "Unable to Determine"]
    risk_distribution = [
        {"name": level.replace(" Risk", ""), "value": sum(record.risk_level == level for record in records)}
        for level in levels
    ]
    category_counts = Counter(record.category for record in records)
    category_distribution = [{"name": key, "value": value} for key, value in category_counts.most_common()]
    pattern_counts: Counter[str] = Counter()
    for record in records:
        pattern_counts.update(json.loads(record.pattern_keys or "[]"))
    pattern_names = {
        "payment": "Payment requests", "credentials": "OTP / credential requests", "urgency": "Urgency pressure",
        "threat": "Threat language", "suspicious_url": "Suspicious URL structure", "unrealistic_reward": "Unusual rewards",
        "impersonation": "Impersonation signals", "sensitive_documents": "Sensitive document requests",
        "secrecy": "Secrecy instructions", "authority": "Authority claims", "contact_mismatch": "Contact mismatches",
        "domain_mismatch": "Domain mismatches", "verification_pressure": "Verification pressure", "unusual_style": "Forceful formatting",
    }
    pattern_distribution = [
        {"name": pattern_names.get(key, key), "value": count}
        for key, count in pattern_counts.most_common(8)
    ]
    recent = [
        {
            "id": record.id,
            "category": record.category,
            "source": record.source,
            "risk_level": record.risk_level,
            "risk_score": record.risk_score,
            "summary": record.summary,
            "created_at": record.created_at.isoformat(),
            "evidence_count": record.evidence_count,
        }
        for record in records[:8]
    ]
    return DashboardResponse(
        total_analyses=len(records),
        high_risk=sum(record.risk_level == "High Risk" for record in records),
        medium_risk=sum(record.risk_level == "Medium Risk" for record in records),
        low_risk=sum(record.risk_level == "Low Risk" for record in records),
        unable_to_determine=sum(record.risk_level == "Unable to Determine" for record in records),
        risk_distribution=risk_distribution,
        category_distribution=category_distribution,
        pattern_distribution=pattern_distribution,
        recent_analyses=recent,
    )
