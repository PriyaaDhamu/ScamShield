from datetime import datetime
from enum import StrEnum

from pydantic import BaseModel, Field


class RiskLevel(StrEnum):
    high = "High Risk"
    medium = "Medium Risk"
    low = "Low Risk"
    unable = "Unable to Determine"


class AnalysisInput(BaseModel):
    text: str = Field(default="", max_length=20000)
    category: str = Field(default="General", max_length=40)
    source: str = Field(default="text", max_length=20)
    title: str | None = Field(default=None, max_length=120)


class Evidence(BaseModel):
    key: str
    title: str
    severity: str
    reason: str
    quote: str | None = None
    points: int = 0


class UrlCheck(BaseModel):
    url: str
    domain: str | None = None
    status: str
    features: list[str] = []
    points: int = 0
    reputation: str = "Not checked: no reputation provider configured"


class Factor(BaseModel):
    label: str
    points: int
    detail: str


class AnalysisResult(BaseModel):
    id: str
    created_at: datetime
    category: str
    source: str
    risk_level: RiskLevel
    risk_score: int
    summary: str
    confidence_note: str
    model_probability: float | None = None
    model_signal_points: int = 0
    model_note: str
    factors: list[Factor]
    evidence: list[Evidence]
    url_checks: list[UrlCheck]
    actions: list[str]
    why: list[str]
    extracted_text: str | None = None


class DemoCase(BaseModel):
    id: str
    title: str
    category: str
    description: str
    fictional: bool
    text: str


class ModelInfo(BaseModel):
    name: str
    dataset_label: str
    dataset_size: int
    test_size: int
    precision: float | None
    recall: float | None
    f1: float | None
    confusion_matrix: list[list[int]] | None
    note: str


class DashboardResponse(BaseModel):
    total_analyses: int
    high_risk: int
    medium_risk: int
    low_risk: int
    unable_to_determine: int
    risk_distribution: list[dict[str, int | str]]
    category_distribution: list[dict[str, int | str]]
    pattern_distribution: list[dict[str, int | str]]
    recent_analyses: list[dict[str, str | int]]
