import re
from dataclasses import dataclass

from app.config import get_settings
from app.schemas import Evidence, UrlCheck


@dataclass(frozen=True)
class SignalRule:
    key: str
    title: str
    pattern: re.Pattern[str]
    reason: str
    quote_group: int = 0


RULES = [
    SignalRule("payment", "Payment or fee requested", re.compile(r"(?i)\b(registration|application|processing|training|placement|interview|security|refundable)\s+(?:fee|charge|deposit)\b|\bpay\s+(?:now|immediately|today|a|the|your)\b|\btransfer\s+(?:money|funds)\b|\bsend\s+(?:₹|rs\.?|inr)\s*[\d,]+"), "Upfront fees are a common fraud pattern. Independently verify the organization and never pay to secure an offer."),
    SignalRule("credentials", "Credential or OTP request", re.compile(r"(?i)\b(?:otp|one[- ]time password|password|passcode|pin|cvv|security code|login credentials)\b"), "Legitimate recruiters and support staff should not ask you to disclose authentication secrets."),
    SignalRule("urgency", "Urgency pressure", re.compile(r"(?i)\b(?:immediately|urgent(?:ly)?|within\s+\d+\s+hours?|today only|last chance|act now|limited time|join(?:ing)? deadline|before midnight|expires? today)\b"), "A compressed deadline can pressure you to skip independent checks."),
    SignalRule("threat", "Threat or penalty language", re.compile(r"(?i)\b(?:account will be (?:blocked|suspended|closed)|legal action|police case|you will be arrested|penalty will apply|account termination)\b"), "Threats tied to a demand are a social-engineering signal; contact the organization through a known channel."),
    SignalRule("unrealistic_reward", "Unusually attractive reward", re.compile(r"(?i)\b(?:guaranteed|no experience required|easy money|assured)\b.{0,55}\b(?:salary|stipend|income|reward|job|selection)\b|\b(?:salary|stipend|earn|reward)\D{0,20}(?:₹|rs\.?|inr)\s*(?:[5-9]\d{3,}|[1-9]\d{4,})"), "An unusually high or guaranteed reward deserves verification against official role or award terms."),
    SignalRule("impersonation", "Possible impersonation claim", re.compile(r"(?i)\b(?:on behalf of|official (?:recruitment|scholarship|bank)|government approved|verified recruiter|company hr|university authority|representative of)\b"), "The message invokes an organization or official role; this claim has not been independently verified."),
    SignalRule("verification_pressure", "Account verification pressure", re.compile(r"(?i)\b(?:verify your (?:account|identity|bank|payment)|kyc update|required to avoid|confirm your account|reactivate your account)\b"), "Unexpected verification requests can be used to harvest personal or account information."),
    SignalRule("sensitive_documents", "Sensitive document request", re.compile(r"(?i)\b(?:aadhaar|aadhar|pan card|passport|bank details|bank account|identity document|government id|social security number)\b"), "Identity and financial documents are sensitive; verify the recipient and necessity independently."),
    SignalRule("secrecy", "Secrecy instruction", re.compile(r"(?i)\b(?:keep this confidential|do not tell anyone|don't tell anyone|keep it secret|do not discuss|exclusive private offer)\b"), "Secrecy can isolate a target from trusted advice and independent verification."),
    SignalRule("authority", "Authority or guaranteed-selection claim", re.compile(r"(?i)\b(?:final warning|official notice|court order|income tax department|reserve bank|selected without interview|guaranteed selection)\b"), "Authority language or guaranteed selection should be checked through a source you find independently."),
]


def _quote(text: str, match: re.Match[str]) -> str:
    start = max(0, match.start() - 45)
    end = min(len(text), match.end() + 65)
    return " ".join(text[start:end].split())[:170]


def _is_negated(text: str, match: re.Match[str]) -> bool:
    before = text[max(0, match.start() - 65):match.start()]
    after = text[match.end():match.end() + 45]
    prefix_negation = re.search(
        r"(?i)\b(?:no|not|never|without|won't|will not|will never|doesn't|does not|do not|don't|did not|isn't|is not|has no)\b(?:\s+[\w,'-]+){0,8}\s*$",
        before,
    )
    suffix_negation = re.match(
        r"(?i)\s*(?:(?:is|are|was|were)\s+)?(?:not\s+)?(?:required|needed|requested|charged|collected|necessary)\b",
        after,
    )
    return prefix_negation is not None or suffix_negation is not None


def detect_signals(text: str, urls: list[UrlCheck]) -> list[Evidence]:
    settings = get_settings()
    evidence: list[Evidence] = []
    for rule in RULES:
        match = next((candidate for candidate in rule.pattern.finditer(text) if not _is_negated(text, candidate)), None)
        if not match:
            continue
        points = settings.risk_weights[rule.key]
        evidence.append(Evidence(
            key=rule.key,
            title=rule.title,
            severity="high" if points >= 20 else "medium" if points >= 9 else "low",
            reason=rule.reason,
            quote=_quote(text, match),
            points=points,
        ))

    suspicious_url_points = min(settings.risk_weights["suspicious_url"], sum(check.points for check in urls))
    if suspicious_url_points:
        flagged = next((check for check in urls if check.points), urls[0])
        evidence.append(Evidence(
            key="suspicious_url",
            title="URL structure needs review",
            severity="high" if suspicious_url_points >= 12 else "medium",
            reason="One or more local URL features make the destination harder to verify. ScamShield did not visit the link or check a reputation feed.",
            quote=flagged.url[:170],
            points=suspicious_url_points,
        ))

    email_domains = {match.lower().split("@", 1)[1].rstrip(".,;:") for match in re.findall(r"(?i)\b[\w.+-]+@[\w.-]+\.[a-z]{2,}\b", text)}
    url_domains = {check.domain for check in urls if check.domain}
    if email_domains and url_domains and not any(
        email == domain or email.endswith(f".{domain}") or domain.endswith(f".{email}")
        for email in email_domains for domain in url_domains
    ):
        points = settings.risk_weights["domain_mismatch"]
        evidence.append(Evidence(
            key="domain_mismatch",
            title="Email and link domains differ",
            severity="medium",
            reason="The sender address and linked site use different domains. This can be legitimate, but the relationship should be verified independently.",
            quote=f"Email domain: {next(iter(email_domains))}; link domain: {next(iter(url_domains))}",
            points=points,
        ))

    personal_domains = {"gmail.com", "outlook.com", "hotmail.com", "yahoo.com", "proton.me", "protonmail.com"}
    organization_claim = re.search(r"(?i)\b(?:internship|scholarship|recruit(?:er|ment)|job offer|placement)\b", text)
    personal_sender = next((domain for domain in email_domains if domain in personal_domains), None)
    if organization_claim and personal_sender:
        points = settings.risk_weights["contact_mismatch"]
        evidence.append(Evidence(
            key="contact_mismatch",
            title="Personal email used for an organization claim",
            severity="medium",
            reason="A free personal mailbox is not proof of fraud, but verify the sender using contact details published on the organization’s official site.",
            quote=f"Sender domain: {personal_sender}",
            points=points,
        ))

    caps = sum(1 for char in text if char.isupper())
    letters = sum(1 for char in text if char.isalpha())
    if letters >= 40 and caps / letters > 0.45 and re.search(r"[!?]{2,}", text):
        points = settings.risk_weights["unusual_style"]
        evidence.append(Evidence(
            key="unusual_style",
            title="Unusually forceful formatting",
            severity="low",
            reason="Heavy capitalization and repeated punctuation can be used to create pressure, though writing style alone is weak evidence.",
            quote=_quote(text, re.search(r"[A-Z]{4,}", text) or re.search(r"[!?]{2,}", text)),
            points=points,
        ))
    return evidence
