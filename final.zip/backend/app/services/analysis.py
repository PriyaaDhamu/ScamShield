from datetime import datetime, timezone
from uuid import uuid4

from app.config import get_settings
from app.schemas import AnalysisInput, AnalysisResult, Factor, RiskLevel
from app.services.classifier import predict_scam_probability
from app.services.signals import detect_signals
from app.services.urls import analyze_urls


def analyze_content(
    request: AnalysisInput,
    *,
    source: str | None = None,
    extracted_text: str | None = None,
) -> AnalysisResult:
    settings = get_settings()
    text = request.text.strip()
    urls = analyze_urls(text)
    evidence = detect_signals(text, urls)
    probability = predict_scam_probability(text) if len(text) >= settings.min_analysis_characters else None
    model_points = 0
    if probability is not None:
        model_points = round(max(0.0, probability - 0.5) * 2 * settings.ml_max_contribution)

    factors = [
        Factor(label=item.title, points=item.points, detail=item.reason)
        for item in evidence
    ]
    if model_points:
        factors.append(Factor(
            label="Synthetic-corpus ML signal",
            points=model_points,
            detail="The TF-IDF model found language patterns similar to synthetic scam examples. This is a supporting signal, not proof.",
        ))
    score = min(100, sum(item.points for item in evidence) + model_points)
    if len(text) < settings.min_analysis_characters:
        level = RiskLevel.unable
        summary = "There is not enough message context for a reliable risk assessment. Review the URL features below and add the surrounding message if available."
    elif score >= settings.high_risk_threshold:
        level = RiskLevel.high
        summary = "Multiple high-risk indicators were detected. Verify independently before taking action."
    elif score >= settings.medium_risk_threshold:
        level = RiskLevel.medium
        summary = "Some scam indicators are present. Pause and verify the sender and request through an independent source."
    else:
        level = RiskLevel.low
        summary = "No strong indicators were detected by these checks. This is not a guarantee that the message or link is safe."

    reasons = [
        "Rule-based findings are separate observable signals; no single one proves fraud.",
        "The model is trained on a small synthetic development dataset, so its probability is not a real-world confidence estimate.",
        "URL analysis is structural and local only. ScamShield did not visit links or query an external reputation service.",
    ]
    if not evidence:
        reasons.insert(0, "No rule-based scam patterns were found in the supplied text.")
    actions = _recommended_actions(evidence, level)
    return AnalysisResult(
        id=str(uuid4()),
        created_at=datetime.now(timezone.utc),
        category=request.category,
        source=source or request.source,
        risk_level=level,
        risk_score=score,
        summary=summary,
        confidence_note="Risk indicators guide review; they cannot establish whether a specific message is genuine.",
        model_probability=round(probability, 3) if probability is not None else None,
        model_signal_points=model_points,
        model_note="Synthetic training corpus; no production accuracy claim." if probability is not None else "Message too short for the local ML model.",
        factors=factors,
        evidence=evidence,
        url_checks=urls,
        actions=actions,
        why=reasons,
        extracted_text=extracted_text,
    )


def _recommended_actions(evidence: list, level: RiskLevel) -> list[str]:
    keys = {item.key for item in evidence}
    actions = []
    if "payment" in keys:
        actions.append("Do not pay a fee or deposit until you independently confirm the organization and process.")
    if "credentials" in keys or "verification_pressure" in keys:
        actions.append("Do not share OTPs, passwords, PINs, or account verification codes.")
    if "sensitive_documents" in keys:
        actions.append("Do not send identity or bank documents until the recipient and purpose are verified.")
    if "suspicious_url" in keys:
        actions.append("Do not open the link from this message; find the official site yourself and compare domains.")
    actions.append("Contact the organization using contact details obtained independently, not the message thread.")
    if level != RiskLevel.low:
        actions.append("Save the message and report it to your institution or the relevant platform if the concern persists.")
    return actions
