import csv
from functools import lru_cache
from pathlib import Path

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, precision_score, recall_score, f1_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

DATA_PATH = Path(__file__).resolve().parents[1] / "data" / "synthetic_training.csv"


def _load_data() -> tuple[list[str], list[str]]:
    texts: list[str] = []
    labels: list[str] = []
    with DATA_PATH.open(encoding="utf-8", newline="") as data_file:
        for row in csv.DictReader(data_file):
            texts.append(row["text"])
            labels.append(row["label"])
    return texts, labels


@lru_cache(maxsize=1)
def get_classifier() -> tuple[Pipeline, dict[str, object]]:
    texts, labels = _load_data()
    train_texts, test_texts, train_labels, test_labels = train_test_split(
        texts, labels, test_size=0.25, random_state=42, stratify=labels
    )
    model = Pipeline([
        ("tfidf", TfidfVectorizer(ngram_range=(1, 2), min_df=1, sublinear_tf=True)),
        ("classifier", LogisticRegression(max_iter=1000, class_weight="balanced", random_state=42)),
    ])
    model.fit(train_texts, train_labels)
    predictions = model.predict(test_texts)
    metrics: dict[str, object] = {
        "name": "TF-IDF + Logistic Regression",
        "dataset_label": "Synthetic development corpus (not representative of real-world scams)",
        "dataset_size": len(texts),
        "test_size": len(test_texts),
        "precision": round(float(precision_score(test_labels, predictions, pos_label="scam", zero_division=0)), 3),
        "recall": round(float(recall_score(test_labels, predictions, pos_label="scam", zero_division=0)), 3),
        "f1": round(float(f1_score(test_labels, predictions, pos_label="scam", zero_division=0)), 3),
        "confusion_matrix": confusion_matrix(test_labels, predictions, labels=["legitimate", "scam"]).tolist(),
        "note": "Held-out metrics are computed on synthetic examples only. They are not a claim of production accuracy or real-world effectiveness.",
    }
    model.fit(texts, labels)
    return model, metrics


def predict_scam_probability(text: str) -> float | None:
    model, _ = get_classifier()
    probabilities = model.predict_proba([text])[0]
    classes = list(model.named_steps["classifier"].classes_)
    return float(probabilities[classes.index("scam")])


def model_metrics() -> dict[str, object]:
    return get_classifier()[1]
