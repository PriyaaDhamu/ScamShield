from io import BytesIO

from fastapi import HTTPException, UploadFile

MAX_TEXT_CHARACTERS = 20000
ALLOWED_TYPES = {
    "application/pdf": "pdf",
    "image/png": "image",
    "image/jpeg": "image",
    "image/webp": "image",
}


async def extract_upload(upload: UploadFile, max_bytes: int) -> tuple[str, str]:
    kind = ALLOWED_TYPES.get(upload.content_type or "")
    if not kind:
        raise HTTPException(status_code=415, detail="Upload a PDF, PNG, JPEG, or WebP file.")
    content = await upload.read(max_bytes + 1)
    if len(content) > max_bytes:
        raise HTTPException(status_code=413, detail=f"File exceeds the {max_bytes // (1024 * 1024)} MB upload limit.")
    if not content:
        raise HTTPException(status_code=400, detail="The uploaded file is empty.")

    try:
        if kind == "pdf":
            from pypdf import PdfReader

            reader = PdfReader(BytesIO(content))
            if len(reader.pages) > 20:
                raise HTTPException(status_code=413, detail="PDFs are limited to 20 pages.")
            text = "\n".join((page.extract_text() or "") for page in reader.pages)
            if not text.strip():
                raise HTTPException(status_code=422, detail="No selectable text found in this PDF. For a scanned PDF, upload a screenshot or image instead.")
            return text[:MAX_TEXT_CHARACTERS], "pdf"

        from PIL import Image, UnidentifiedImageError
        import pytesseract

        try:
            image = Image.open(BytesIO(content)).convert("RGB")
        except UnidentifiedImageError as exc:
            raise HTTPException(status_code=400, detail="The image file could not be decoded.") from exc
        if image.width * image.height > 20_000_000:
            raise HTTPException(status_code=413, detail="Image dimensions exceed the 20-megapixel limit.")
        try:
            text = pytesseract.image_to_string(image)
        except pytesseract.TesseractNotFoundError as exc:
            raise HTTPException(status_code=503, detail="OCR engine unavailable. Install Tesseract OCR and configure its executable to enable screenshot analysis.") from exc
        if not text.strip():
            raise HTTPException(status_code=422, detail="OCR did not find readable text. Try a sharper screenshot with visible message text.")
        return text[:MAX_TEXT_CHARACTERS], "screenshot"
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=400, detail="The uploaded file could not be processed.") from exc
