import ipaddress
import re
from urllib.parse import urlparse

from app.config import get_settings
from app.schemas import UrlCheck

URL_PATTERN = re.compile(r"(?i)\b(?:https?://|www\.)[^\s<>\"']+|\b[a-z0-9][a-z0-9.-]*\.[a-z]{2,}(?:/[^\s<>\"']*)?")
SHORTENERS = {"bit.ly", "t.co", "tinyurl.com", "goo.gl", "ow.ly", "is.gd", "cutt.ly"}


def find_urls(text: str) -> list[str]:
    found = []
    for candidate in URL_PATTERN.findall(text):
        cleaned = candidate.rstrip(".,!?;:)]}")
        if cleaned and cleaned not in found:
            found.append(cleaned)
    return found[:10]


def inspect_url(candidate: str) -> UrlCheck:
    settings = get_settings()
    normalized = candidate if "://" in candidate else f"http://{candidate}"
    parsed = urlparse(normalized)
    host = (parsed.hostname or "").lower().rstrip(".")
    features: list[str] = []
    points = 0

    if not host:
        return UrlCheck(url=candidate, status="Could not parse URL", features=["The address could not be parsed locally."], points=0)

    try:
        ipaddress.ip_address(host.strip("[]"))
        features.append("The hostname is a raw IP address rather than a readable domain.")
        points += settings.risk_weights["suspicious_url"]
    except ValueError:
        pass

    labels = host.split(".")
    if len(labels) >= 5:
        features.append("The address uses several nested subdomains; confirm the registered domain carefully.")
        points += min(6, settings.risk_weights["suspicious_url"] // 3)
    if any(label.startswith("xn--") for label in labels):
        features.append("The domain includes an internationalized/punycode label that can obscure lookalike characters.")
        points += min(8, settings.risk_weights["suspicious_url"] // 2)
    if len(candidate) > 120:
        features.append("The URL is unusually long, which can make its destination harder to inspect.")
        points += min(5, settings.risk_weights["suspicious_url"] // 3)
    if re.search(r"[%@\\]", candidate):
        features.append("The URL contains encoded, at-sign, or backslash characters that warrant careful inspection.")
        points += min(5, settings.risk_weights["suspicious_url"] // 3)
    if host in SHORTENERS:
        features.append("A URL-shortening service hides the final destination from this local check.")
        points += min(5, settings.risk_weights["suspicious_url"] // 3)
    if re.search(r"(?i)(login|verify|secure|account|bank|wallet|gift|claim)[-.]", host):
        features.append("The hostname combines a trust-sensitive term with extra labels; verify the registered domain independently.")
        points += min(6, settings.risk_weights["suspicious_url"] // 3)
    if parsed.scheme != "https":
        features.append("This URL does not use HTTPS. That alone does not establish that it is malicious.")

    status = "Review carefully" if points else "No strong local URL indicators"
    if not points:
        features.append("No strong structural warning signs were found by the local checks; this is not a safety guarantee.")
    return UrlCheck(url=candidate, domain=host, status=status, features=features, points=min(points, settings.risk_weights["suspicious_url"]), reputation="Not checked: no reputation provider configured")


def analyze_urls(text: str, explicit_url: str | None = None) -> list[UrlCheck]:
    candidates = find_urls(text)
    if explicit_url:
        for value in find_urls(explicit_url) or [explicit_url]:
            if value not in candidates:
                candidates.insert(0, value)
    return [inspect_url(candidate) for candidate in candidates[:10]]
