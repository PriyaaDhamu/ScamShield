from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file="../.env", env_file_encoding="utf-8", extra="ignore")

    app_name: str = "ScamShield API"
    database_url: str = "sqlite:///./scamshield.db"
    cors_origins: str = "http://localhost:5173,http://127.0.0.1:5173,http://localhost:5500,http://127.0.0.1:5500"
    max_upload_mb: int = 8
    min_analysis_characters: int = 25
    high_risk_threshold: int = 65
    medium_risk_threshold: int = 35
    ml_max_contribution: int = 15
    risk_weights: dict[str, int] = {
        "payment": 25,
        "credentials": 25,
        "urgency": 10,
        "threat": 12,
        "suspicious_url": 15,
        "unrealistic_reward": 12,
        "impersonation": 12,
        "sensitive_documents": 10,
        "secrecy": 8,
        "authority": 8,
        "contact_mismatch": 10,
        "domain_mismatch": 12,
        "verification_pressure": 12,
        "unusual_style": 4,
    }


@lru_cache
def get_settings() -> Settings:
    return Settings()
