from app.services.classifier import model_metrics


if __name__ == "__main__":
    metrics = model_metrics()
    print(f"Model: {metrics['name']}")
    print(f"Dataset: {metrics['dataset_label']}")
    print(f"Rows: {metrics['dataset_size']} (test split: {metrics['test_size']})")
    print(f"Precision: {metrics['precision']} | Recall: {metrics['recall']} | F1: {metrics['f1']}")
    print(f"Confusion matrix [legitimate, scam]: {metrics['confusion_matrix']}")
    print(metrics["note"])
