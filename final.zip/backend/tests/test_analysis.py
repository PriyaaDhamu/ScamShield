from app.schemas import AnalysisInput, RiskLevel
from app.services.analysis import analyze_content
from app.services.classifier import model_metrics
from app.services.urls import inspect_url


def test_multiple_independent_signals_raise_risk():
    result = analyze_content(AnalysisInput(
        category="Internship",
        text="Selected for internship. Pay ₹2,000 registration fee immediately and send your OTP and Aadhaar before tonight.",
    ))
    keys = {item.key for item in result.evidence}
    assert {"payment", "credentials", "urgency", "sensitive_documents"} <= keys
    assert result.risk_level == RiskLevel.high
    assert 0 <= result.risk_score <= 100
    assert result.actions


def test_one_payment_indicator_does_not_establish_high_risk():
    result = analyze_content(AnalysisInput(
        text="Please pay a small registration fee to apply for this internship.",
    ))
    assert "payment" in {item.key for item in result.evidence}
    assert result.risk_level != RiskLevel.high


def test_insufficient_context_uses_uncertain_label():
    result = analyze_content(AnalysisInput(text="verify now"))
    assert result.risk_level == RiskLevel.unable
    assert result.model_probability is None


def test_https_alone_is_not_a_suspicious_url_finding():
    result = inspect_url("https://careers.example.org/internships")
    assert result.points == 0
    assert "does not use HTTPS" not in " ".join(result.features)


def test_explicit_denials_do_not_count_as_fee_or_credential_requests():
    result = analyze_content(AnalysisInput(
        text="There is no application or training fee. Our recruiter will never ask for your OTP or password.",
    ))
    keys = {item.key for item in result.evidence}
    assert "payment" not in keys
    assert "credentials" not in keys


def test_model_reports_synthetic_held_out_metrics():
    metrics = model_metrics()
    assert metrics["dataset_size"] >= 40
    assert metrics["test_size"] > 0
    assert len(metrics["confusion_matrix"]) == 2
    assert "synthetic" in metrics["note"].lower()
