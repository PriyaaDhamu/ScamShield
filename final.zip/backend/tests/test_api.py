from io import BytesIO

import pytest
from PIL import Image
from pypdf import PdfWriter
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.database import Base, get_db
from app.main import app


@pytest.fixture
def client():
    test_engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    TestSession = sessionmaker(bind=test_engine, autoflush=False, autocommit=False)
    Base.metadata.create_all(bind=test_engine)

    def override_get_db():
        session = TestSession()
        try:
            yield session
        finally:
            session.close()

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()
    Base.metadata.drop_all(bind=test_engine)
    test_engine.dispose()


def test_demo_cases_are_fictional_and_demo_results_are_not_persisted(client):
    cases = client.get("/api/demos").json()
    assert len(cases) == 6
    assert all(case["fictional"] for case in cases)

    result = client.post("/api/demos/internship-fee/analyze").json()
    assert result["source"] == "demo"
    assert result["risk_level"] == "High Risk"
    assert {item["key"] for item in result["evidence"]} >= {"payment", "sensitive_documents"}
    assert client.get("/api/dashboard").json()["total_analyses"] == 0


def test_text_analysis_persists_only_dashboard_summary(client):
    response = client.post("/api/analyze", json={
        "category": "Internship",
        "text": "Selected for internship. Pay ₹2,000 registration fee immediately and send your OTP and Aadhaar before tonight.",
    })
    assert response.status_code == 200
    result = response.json()
    assert result["risk_level"] == "High Risk"
    assert "text" not in result

    dashboard = client.get("/api/dashboard").json()
    assert dashboard["total_analyses"] == 1
    assert dashboard["high_risk"] == 1
    assert dashboard["recent_analyses"][0]["category"] == "Internship"


def test_empty_text_is_rejected(client):
    response = client.post("/api/analyze", json={"text": "  "})
    assert response.status_code == 422


def test_standalone_url_check_does_not_flag_https_alone(client):
    response = client.get("/api/url-check", params={"url": "https://careers.example.org/internships"})
    assert response.status_code == 200
    assert response.json()["points"] == 0
    assert "not a safety guarantee" in response.json()["features"][-1].lower()


def test_unsupported_upload_type_is_rejected(client):
    response = client.post(
        "/api/analyze/upload",
        data={"category": "General", "context": ""},
        files={"file": ("message.txt", b"ordinary message text", "text/plain")},
    )
    assert response.status_code == 415


def test_blank_pdf_returns_extraction_error(client):
    buffer = BytesIO()
    writer = PdfWriter()
    writer.add_blank_page(width=100, height=100)
    writer.write(buffer)
    response = client.post(
        "/api/analyze/upload",
        data={"category": "General", "context": ""},
        files={"file": ("blank.pdf", buffer.getvalue(), "application/pdf")},
    )
    assert response.status_code == 422
    assert "No selectable text" in response.json()["detail"]


def test_blank_screenshot_reports_ocr_state_without_fabricating_result(client):
    buffer = BytesIO()
    Image.new("RGB", (40, 40), "white").save(buffer, format="PNG")
    response = client.post(
        "/api/analyze/upload",
        data={"category": "General", "context": ""},
        files={"file": ("blank.png", buffer.getvalue(), "image/png")},
    )
    assert response.status_code in {422, 503}
    assert "risk_score" not in response.json()
