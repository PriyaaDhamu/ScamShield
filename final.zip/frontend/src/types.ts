export type RiskLevel = 'High Risk' | 'Medium Risk' | 'Low Risk' | 'Unable to Determine'

export interface Evidence {
  key: string
  title: string
  severity: 'high' | 'medium' | 'low'
  reason: string
  quote?: string | null
  points: number
}

export interface UrlCheck {
  url: string
  domain?: string | null
  status: string
  features: string[]
  points: number
  reputation: string
}

export interface Factor {
  label: string
  points: number
  detail: string
}

export interface AnalysisResult {
  id: string
  created_at: string
  category: string
  source: string
  risk_level: RiskLevel
  risk_score: number
  summary: string
  confidence_note: string
  model_probability?: number | null
  model_signal_points: number
  model_note: string
  factors: Factor[]
  evidence: Evidence[]
  url_checks: UrlCheck[]
  actions: string[]
  why: string[]
  extracted_text?: string | null
}

export interface DemoCase {
  id: string
  title: string
  category: string
  description: string
  fictional: boolean
  text: string
}

export interface DashboardData {
  total_analyses: number
  high_risk: number
  medium_risk: number
  low_risk: number
  unable_to_determine: number
  risk_distribution: { name: string; value: number }[]
  category_distribution: { name: string; value: number }[]
  pattern_distribution: { name: string; value: number }[]
  recent_analyses: {
    id: string
    category: string
    source: string
    risk_level: RiskLevel
    risk_score: number
    summary: string
    created_at: string
    evidence_count: number
  }[]
}

export interface ModelInfo {
  name: string
  dataset_label: string
  dataset_size: number
  test_size: number
  precision: number | null
  recall: number | null
  f1: number | null
  confusion_matrix: number[][] | null
  note: string
}
