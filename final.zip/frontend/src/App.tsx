import { useCallback, useEffect, useState } from 'react'
import { Activity, ArrowUpRight, BookOpenCheck, ChevronRight, CircleHelp, FileSearch, LayoutDashboard, Link2, ShieldCheck } from 'lucide-react'
import { analyzeDemo, analyzeText, analyzeUpload } from './api'
import type { AnalysisResult } from './types'
import Overview from './components/Overview'
import Analyzer from './components/Analyzer'
import UrlChecker from './components/UrlChecker'
import DemoCenter from './components/DemoCenter'

type Page = 'overview' | 'analyze' | 'url' | 'demos'

const navigation: { id: Page; label: string; icon: typeof LayoutDashboard }[] = [
  { id: 'overview', label: 'Overview', icon: LayoutDashboard },
  { id: 'analyze', label: 'Student scam check', icon: FileSearch },
  { id: 'url', label: 'URL inspection', icon: Link2 },
  { id: 'demos', label: 'Demo center', icon: BookOpenCheck },
]

export default function App() {
  const [page, setPage] = useState<Page>('overview')
  const [result, setResult] = useState<AnalysisResult | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const refresh = useCallback(() => window.dispatchEvent(new Event('scamshield:refresh-dashboard')), [])

  const runAnalysis = useCallback(async (text: string, category: string, file?: File | null, context = '') => {
    setLoading(true)
    setError('')
    try {
      const data = file ? await analyzeUpload(file, category, context) : await analyzeText(text, category)
      setResult(data)
      setPage('analyze')
      refresh()
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Analysis failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }, [refresh])

  const runDemo = useCallback(async (id: string) => {
    setLoading(true)
    setError('')
    try {
      setResult(await analyzeDemo(id))
      setPage('analyze')
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Demo analysis failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    document.title = 'ScamShield | Don’t trust. Verify.'
  }, [])

  const activeLabel = navigation.find((item) => item.id === page)?.label ?? 'Overview'

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <button className="brand" onClick={() => setPage('overview')} aria-label="ScamShield overview">
          <span className="brand-mark"><ShieldCheck size={21} strokeWidth={2.2} /></span>
          <span className="brand-name">scam<span>shield</span><sup>®</sup></span>
        </button>

        <div className="sidebar-caption">WORKSPACE</div>
        <nav className="side-nav" aria-label="Main navigation">
          {navigation.map(({ id, label, icon: Icon }) => (
            <button className={`nav-item ${page === id ? 'is-active' : ''}`} key={id} onClick={() => setPage(id)} title={label}>
              <Icon size={17} strokeWidth={1.8} />
              <span>{label}</span>
              {id === 'analyze' && <ArrowUpRight className="nav-cue" size={14} />}
            </button>
          ))}
        </nav>

        <div className="sidebar-spacer" />
        <div className="privacy-note">
          <div className="privacy-icon"><CircleHelp size={15} /></div>
          <div><strong>Built for careful decisions</strong><span>Signals, not accusations.</span></div>
        </div>
        <div className="sidebar-status"><span className="status-dot" /> Local analysis active</div>
        <div className="sidebar-footer"><span>SCAMSHIELD LABS</span><span>PROTOTYPE 01</span></div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <div className="breadcrumb"><span>Workspace</span><ChevronRight size={13} /><strong>{activeLabel}</strong></div>
          <div className="topbar-right">
            <span className="environment-tag"><span className="environment-dot" /> DEMO ENVIRONMENT</span>
            <button className="icon-button help-button" title="API documentation" onClick={() => window.open('http://localhost:8000/docs', '_blank', 'noopener,noreferrer')} aria-label="Open API documentation"><CircleHelp size={17} /></button>
          </div>
        </header>

        {error && page !== 'analyze' && page !== 'demos' && <div className="global-error" role="alert"><Activity size={16} />{error}<button onClick={() => setError('')} aria-label="Dismiss error">×</button></div>}
        {page === 'overview' && <Overview onNavigate={setPage} />}
        {page === 'analyze' && <Analyzer result={result} busy={loading} error={error} onAnalyze={runAnalysis} onClearError={() => setError('')} />}
        {page === 'url' && <UrlChecker />}
        {page === 'demos' && <DemoCenter busy={loading} error={error} onAnalyze={runDemo} />}

        <footer className="content-footer"><span>ScamShield helps you pause, inspect, and verify.</span><a href="http://localhost:8000/docs" target="_blank" rel="noreferrer">API reference <ArrowUpRight size={13} /></a></footer>
      </main>
    </div>
  )
}
