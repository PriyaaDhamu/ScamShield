import type { AnalysisResult, DashboardData, DemoCase, ModelInfo, UrlCheck } from './types'

const API_HOST = window.location.hostname || 'localhost'
const API_ROOT = (import.meta.env.VITE_API_URL ?? `http://${API_HOST}:8000/api`).replace(/\/$/, '')

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let response: Response
  try {
    response = await fetch(`${API_ROOT}${path}`, init)
  } catch {
    throw new Error('Can’t reach the ScamShield API. Start the backend at http://localhost:8000 and try again.')
  }
  if (!response.ok) {
    let message = `Request failed (${response.status}).`
    try {
      const body = await response.json() as { detail?: string }
      if (body.detail) message = body.detail
    } catch {
      // Keep the HTTP status message when the server response is not JSON.
    }
    throw new Error(message)
  }
  return response.json() as Promise<T>
}

export function getDashboard() {
  return request<DashboardData>('/dashboard')
}

export function getModelInfo() {
  return request<ModelInfo>('/model-info')
}

export function getDemoCases() {
  return request<DemoCase[]>('/demos')
}

export function analyzeText(text: string, category: string) {
  return request<AnalysisResult>('/analyze', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text, category, source: 'text' }),
  })
}

export function analyzeUpload(file: File, category: string, context: string) {
  const form = new FormData()
  form.append('file', file)
  form.append('category', category)
  form.append('context', context)
  return request<AnalysisResult>('/analyze/upload', { method: 'POST', body: form })
}

export function checkUrl(url: string) {
  return request<UrlCheck>(`/url-check?url=${encodeURIComponent(url)}`)
}

export function analyzeDemo(id: string) {
  return request<AnalysisResult>(`/demos/${encodeURIComponent(id)}/analyze`, { method: 'POST' })
}
