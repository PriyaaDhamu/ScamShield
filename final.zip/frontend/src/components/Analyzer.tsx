import { useRef, useState } from 'react'
import { ArrowRight, FileImage, FileText, Info, LoaderCircle, Paperclip, ShieldCheck, Sparkles, X } from 'lucide-react'
import type { AnalysisResult } from '../types'
import ResultReport from './ResultReport'

const categories = ['Internship', 'Job', 'Scholarship', 'College Notice', 'Bank/Payment', 'Social Media', 'Delivery', 'General']

export default function Analyzer({
  result,
  busy,
  error,
  onAnalyze,
  onClearError,
}: {
  result: AnalysisResult | null
  busy: boolean
  error: string
  onAnalyze: (text: string, category: string, file?: File | null, context?: string) => void
  onClearError: () => void
}) {
  const [text, setText] = useState('')
  const [category, setCategory] = useState('Internship')
  const [context, setContext] = useState('')
  const [file, setFile] = useState<File | null>(null)
  const [dragging, setDragging] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)

  function acceptFile(nextFile?: File) {
    if (!nextFile) return
    if (!/^(application\/pdf|image\/(png|jpeg|webp))$/.test(nextFile.type)) return
    setFile(nextFile)
  }

  function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (busy || (!file && !text.trim())) return
    onAnalyze(text, category, file, context)
  }

  return (
    <div className="page-content analyzer-page">
      <div className="page-intro">
        <div><span className="section-kicker">STUDENT SCAM CHECK</span><h1>Pause. Then inspect.</h1><p>Paste the message as received, add relevant context, or upload an offer letter or screenshot.</p></div>
        <div className="private-badge"><ShieldCheck size={15} /> MESSAGE TEXT ISN’T STORED</div>
      </div>

      <div className="analyzer-layout">
        <form className="analysis-form" onSubmit={submit}>
          <div className="form-topline"><span className="form-step">01</span><div><strong>What would you like checked?</strong><span>Choose the closest match to help focus the analysis.</span></div></div>
          <label className="field-label" htmlFor="message-category">MESSAGE CATEGORY</label>
          <select id="message-category" value={category} onChange={(event) => setCategory(event.target.value)}>{categories.map((item) => <option key={item}>{item}</option>)}</select>
          {category === 'Internship' && <div className="student-focus"><Sparkles size={15} /><span>Internship focus: fees, stipend claims, recruiter contact, deadlines, identity documents, OTPs, and linked domains.</span></div>}
          <label className="field-label" htmlFor="message-text">MESSAGE OR OFFER TEXT <span>OPTIONAL WITH AN UPLOAD</span></label>
          <textarea id="message-text" value={text} onChange={(event) => setText(event.target.value)} placeholder="Paste the SMS, email, job offer, scholarship notice, or social message here…" rows={7} maxLength={20000} />
          <div className="character-count">{text.length.toLocaleString()} / 20,000 characters</div>

          <input ref={inputRef} className="visually-hidden" type="file" accept="application/pdf,image/png,image/jpeg,image/webp" onChange={(event) => acceptFile(event.target.files?.[0])} />
          <div className={`upload-zone ${dragging ? 'upload-dragging' : ''}`} onClick={() => inputRef.current?.click()} onDragOver={(event) => { event.preventDefault(); setDragging(true) }} onDragLeave={() => setDragging(false)} onDrop={(event) => { event.preventDefault(); setDragging(false); acceptFile(event.dataTransfer.files[0]) }} role="button" tabIndex={0} onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') inputRef.current?.click() }}>
            <span className="upload-icon"><Paperclip size={17} /></span>
            {file ? <div className="selected-file"><span>{file.type === 'application/pdf' ? <FileText size={15} /> : <FileImage size={15} />}{file.name}</span><button type="button" className="remove-file" aria-label="Remove upload" onClick={(event) => { event.stopPropagation(); setFile(null); if (inputRef.current) inputRef.current.value = '' }}><X size={15} /></button></div> : <div><strong>Drop a screenshot or offer letter</strong><span>PDF, PNG, JPG or WebP · up to 8 MB</span></div>}
            {!file && <span className="upload-browse">BROWSE</span>}
          </div>
          {file && <label className="context-field" htmlFor="extra-context">ADDITIONAL CONTEXT <span>OPTIONAL</span><input id="extra-context" value={context} onChange={(event) => setContext(event.target.value)} placeholder="Where did you receive this?" /></label>}
          <div className="upload-note"><Info size={14} /><span>PDF text is extracted locally. Screenshot OCR needs the optional Tesseract engine installed.</span></div>
          {error && <div className="form-error" role="alert">{error}<button type="button" onClick={onClearError} aria-label="Dismiss error">×</button></div>}
          <div className="form-submit-row"><button className="button button-dark" type="submit" disabled={busy || (!file && !text.trim())}>{busy ? <><LoaderCircle className="spin" size={17} /> Analyzing…</> : <>Analyze for risk <ArrowRight size={16} /></>}</button><span>Usually under a few seconds</span></div>
        </form>

        <aside className="analysis-side-note">
          <div className="analysis-note-top"><span className="note-illustration"><ShieldCheck size={25} /></span><span className="section-kicker">EVIDENCE, NOT A VERDICT</span></div>
          <h2>One red flag<br />isn’t the whole story.</h2>
          <p>ScamShield combines message patterns, local URL structure, sender consistency, and a synthetic-corpus language model. Each finding is shown with its reason.</p>
          <div className="layer-list"><div><span>01</span><strong>Language patterns</strong><i /></div><div><span>02</span><strong>URL structure</strong><i /></div><div><span>03</span><strong>Identity consistency</strong><i /></div><div><span>04</span><strong>Evidence aggregation</strong><i /></div></div>
          <div className="analysis-note-foot"><Info size={14} /><span>Low risk never means guaranteed safe.</span></div>
        </aside>
      </div>
      {result && <ResultReport result={result} />}
      <div className="privacy-footnote"><Info size={14} /><span>Analysis summaries are stored for your local dashboard. Raw messages and files are not retained.</span></div>
    </div>
  )
}
