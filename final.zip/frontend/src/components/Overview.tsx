import { useCallback, useEffect, useState } from 'react'
import { ArrowDownRight, ArrowRight, ArrowUpRight, BadgeCheck, FileSearch, Fingerprint, ShieldAlert, ShieldCheck } from 'lucide-react'
import { Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { getDashboard, getModelInfo } from '../api'
import type { DashboardData, ModelInfo } from '../types'

type Navigate = (page: 'overview' | 'analyze' | 'url' | 'demos') => void

const riskColors = ['#ef715c', '#e8b052', '#69a986', '#a4aaa4']
const patternColors = ['#dcfb63', '#b9db43', '#94b735', '#76982f', '#557526', '#405b22', '#33491f', '#28391c']

export default function Overview({ onNavigate }: { onNavigate: Navigate }) {
  const [data, setData] = useState<DashboardData | null>(null)
  const [model, setModel] = useState<ModelInfo | null>(null)
  const [error, setError] = useState('')

  const load = useCallback(async () => {
    try {
      const [dashboard, modelInfo] = await Promise.all([getDashboard(), getModelInfo()])
      setData(dashboard)
      setModel(modelInfo)
      setError('')
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Dashboard could not be loaded.')
    }
  }, [])

  useEffect(() => {
    void load()
    const refresh = () => { void load() }
    window.addEventListener('scamshield:refresh-dashboard', refresh)
    return () => window.removeEventListener('scamshield:refresh-dashboard', refresh)
  }, [load])

  const stats = data ? [
    { label: 'Analyses run', value: data.total_analyses, icon: FileSearch, kind: 'ink' },
    { label: 'High risk', value: data.high_risk, icon: ShieldAlert, kind: 'coral' },
    { label: 'Needs a closer look', value: data.medium_risk, icon: Fingerprint, kind: 'amber' },
    { label: 'No strong signals', value: data.low_risk, icon: BadgeCheck, kind: 'green' },
  ] : []

  return (
    <div className="page-content overview-page">
      <section className="hero-band">
        <div className="hero-copy">
          <div className="eyebrow"><span className="eyebrow-line" /> STUDENT SECURITY INTELLIGENCE</div>
          <h1>Don’t trust.<br /><span>Verify.</span></h1>
          <p>Scams move fast. Your decisions shouldn’t. Check the signals before sharing money, personal details, or a click.</p>
          <div className="hero-actions">
            <button className="button button-lime" onClick={() => onNavigate('analyze')}>Analyze a message <ArrowRight size={16} /></button>
            <button className="button button-outline" onClick={() => onNavigate('url')}><span className="url-button-icon"><ArrowUpRight size={14} /></span> Check a URL</button>
          </div>
        </div>
        <div className="signal-art" aria-label="Message analyzed into risk, evidence and next steps">
          <div className="signal-orbit orbit-one" /><div className="signal-orbit orbit-two" />
          <div className="signal-core"><ShieldCheck size={41} strokeWidth={1.3} /><span>SCAM<br />SHIELD</span></div>
          <div className="signal-label signal-label-top"><span className="signal-square" /> MESSAGE <i /></div>
          <div className="signal-label signal-label-left"><span className="signal-square square-lime" /> RISK</div>
          <div className="signal-label signal-label-right"><span className="signal-square square-coral" /> EVIDENCE</div>
          <div className="signal-label signal-label-bottom"><span className="signal-square square-white" /> ACTION <i /></div>
          <div className="art-index">01 / SIGNAL FLOW</div>
        </div>
        <div className="hero-footnote"><span>01</span> MULTI-LAYER ANALYSIS <span className="footnote-separator">/</span> HUMAN-READABLE EVIDENCE</div>
      </section>

      <div className="section-heading dashboard-heading">
        <div><span className="section-kicker">YOUR ACTIVITY</span><h2>Risk, at a glance.</h2></div>
        <button className="text-action" onClick={() => onNavigate('demos')}>Open demo center <ArrowUpRight size={15} /></button>
      </div>

      {error && <div className="inline-error" role="alert">{error}<button className="text-action" onClick={() => void load()}>Retry <ArrowRight size={14} /></button></div>}
      <div className="metric-grid" aria-label="Analysis totals">
        {stats.map(({ label, value, icon: Icon, kind }, index) => (
          <div className={`metric-tile metric-${kind} reveal-in`} style={{ animationDelay: `${index * 70}ms` }} key={label}>
            <div className="metric-top"><span>{label}</span><Icon size={17} strokeWidth={1.8} /></div>
            <div className="metric-value">{data ? value.toLocaleString() : '—'}</div>
            <div className="metric-bottom"><span className="metric-bar"><i style={{ width: data && data.total_analyses ? `${Math.max(5, Math.round((value / data.total_analyses) * 100))}%` : '0%' }} /></span><span>{index === 0 ? 'ALL TIME' : 'OF TOTAL'}</span></div>
          </div>
        ))}
      </div>

      <div className="chart-grid">
        <section className="chart-panel risk-panel">
          <div className="panel-heading"><div><span className="section-kicker">SIGNAL BREAKDOWN</span><h3>Risk distribution</h3></div><span className="live-label"><i /> LIVE</span></div>
          {data?.total_analyses ? <div className="risk-chart-layout">
            <div className="donut-wrap">
              <ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={data.risk_distribution} dataKey="value" nameKey="name" innerRadius="72%" outerRadius="91%" paddingAngle={3} stroke="none">{data.risk_distribution.map((entry, index) => <Cell key={entry.name} fill={riskColors[index]} />)}</Pie><Tooltip formatter={(value) => [value, 'Analyses']} /></PieChart></ResponsiveContainer>
              <div className="donut-center"><strong>{data.total_analyses}</strong><span>TOTAL</span></div>
            </div>
            <div className="legend-list">{data.risk_distribution.map((entry, index) => <div className="legend-row" key={entry.name}><span className="legend-dot" style={{ background: riskColors[index] }} /><span>{entry.name}</span><strong>{entry.value}</strong></div>)}</div>
          </div> : <div className="empty-chart"><div className="empty-mark"><ShieldCheck size={20} /></div><strong>No analyses yet</strong><span>Try a fictional case to see the risk profile appear here.</span><button className="text-action" onClick={() => onNavigate('demos')}>Explore demos <ArrowRight size={14} /></button></div>}
        </section>

        <section className="chart-panel pattern-panel">
          <div className="panel-heading"><div><span className="section-kicker">REPEATED SIGNALS</span><h3>Patterns detected</h3></div><span className="chart-note">EVIDENCE COUNTS</span></div>
          {data?.pattern_distribution.length ? <div className="pattern-chart"><ResponsiveContainer width="100%" height="100%"><BarChart data={data.pattern_distribution.slice(0, 5)} layout="vertical" margin={{ left: 2, right: 26, top: 2, bottom: 0 }}><CartesianGrid horizontal={false} stroke="#e4e8e0" /><XAxis type="number" hide allowDecimals={false} /><YAxis type="category" dataKey="name" axisLine={false} tickLine={false} width={145} tick={{ fill: '#59615b', fontSize: 11 }} /><Tooltip cursor={{ fill: '#edf2e8' }} /><Bar dataKey="value" radius={[0, 3, 3, 0]} barSize={13}>{data.pattern_distribution.slice(0, 5).map((entry, index) => <Cell key={entry.name} fill={patternColors[index]} />)}</Bar></BarChart></ResponsiveContainer></div> : <div className="empty-chart empty-chart-short"><div className="empty-mark"><ArrowDownRight size={20} /></div><strong>Patterns will appear here</strong><span>Evidence categories stay aggregated; message text is not stored.</span></div>}
        </section>
      </div>

      <section className="chart-panel category-panel">
        <div className="panel-heading"><div><span className="section-kicker">STUDENT WORKFLOW</span><h3>Checks by category</h3></div><span className="chart-note">ANALYSIS COUNT</span></div>
        {data?.category_distribution.length ? <div className="category-chart"><ResponsiveContainer width="100%" height="100%"><BarChart data={data.category_distribution.slice(0, 7)} layout="vertical" margin={{ left: 2, right: 30, top: 2, bottom: 0 }}><CartesianGrid horizontal={false} stroke="#e4e8e0" /><XAxis type="number" hide allowDecimals={false} /><YAxis type="category" dataKey="name" axisLine={false} tickLine={false} width={145} tick={{ fill: '#59615b', fontSize: 11 }} /><Tooltip cursor={{ fill: '#edf2e8' }} /><Bar dataKey="value" name="Analyses" fill="#95b735" radius={[0, 3, 3, 0]} barSize={12} /></BarChart></ResponsiveContainer></div> : <div className="empty-chart empty-chart-short"><div className="empty-mark"><FileSearch size={20} /></div><strong>Category mix is empty</strong><span>Run a check to see which student workflows are represented.</span></div>}
      </section>

      <div className="lower-grid">
        <section className="recent-section">
          <div className="panel-heading"><div><span className="section-kicker">LATEST CHECKS</span><h3>Recent analyses</h3></div><button className="icon-link" onClick={() => onNavigate('analyze')} aria-label="Start an analysis"><ArrowUpRight size={17} /></button></div>
          {data?.recent_analyses.length ? <div className="recent-table">
            <div className="recent-head"><span>CATEGORY / SOURCE</span><span>INDICATORS</span><span>RISK</span><span>SCORE</span></div>
            {data.recent_analyses.slice(0, 5).map((row) => <div className="recent-row" key={row.id}>
              <div className="recent-category"><strong>{row.category}</strong><span>{row.source === 'demo' ? 'FICTIONAL DEMO' : `${row.source.toUpperCase()} · ${new Date(row.created_at).toLocaleDateString()}`}</span></div>
              <span className="evidence-count">{row.evidence_count} signals</span>
              <span className={`risk-pill ${riskClass(row.risk_level)}`}>{row.risk_level.replace(' Risk', '').replace('Unable to Determine', 'Unknown')}</span>
              <span className="recent-score">{row.risk_score}<small>/100</small></span>
            </div>)}
          </div> : <div className="recent-empty"><span>Your recent checks will show up here.</span><button className="text-action" onClick={() => onNavigate('analyze')}>Start your first check <ArrowRight size={14} /></button></div>}
        </section>

        <aside className="model-panel">
          <div className="model-heading"><div className="model-icon"><ActivityIcon /></div><div><span className="section-kicker">LOCAL CLASSIFIER</span><h3>{model?.name ?? 'Loading model…'}</h3></div></div>
          {model && <>
            <div className="model-metrics"><ModelMetric label="PRECISION" value={model.precision} /><ModelMetric label="RECALL" value={model.recall} /><ModelMetric label="F1" value={model.f1} /></div>
            <p className="model-warning">{model.dataset_label}. Held-out scores are synthetic-only, not real-world accuracy.</p>
          </>}
          <div className="model-stack"><span>TF-IDF</span><i /> <span>LOGISTIC REGRESSION</span><i /> <span>RULE EVIDENCE</span></div>
        </aside>
      </div>
      <div className="dashboard-disclaimer"><ShieldCheck size={15} /><span>Risk labels are guidance, not guarantees. Verify important offers through a source you find independently.</span></div>
    </div>
  )
}

function ModelMetric({ label, value }: { label: string; value: number | null }) {
  return <div><span>{label}</span><strong>{value == null ? '—' : value.toFixed(2)}</strong></div>
}

function ActivityIcon() {
  return <span className="activity-bars"><i /><i /><i /><i /></span>
}

function riskClass(level: string) {
  if (level === 'High Risk') return 'pill-high'
  if (level === 'Medium Risk') return 'pill-medium'
  if (level === 'Low Risk') return 'pill-low'
  return 'pill-unknown'
}
