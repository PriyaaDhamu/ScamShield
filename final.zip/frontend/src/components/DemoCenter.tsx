import { useEffect, useState } from 'react'
import { ArrowRight, BadgeCheck, BookOpenCheck, LoaderCircle, ShieldAlert } from 'lucide-react'
import { getDemoCases } from '../api'
import type { DemoCase } from '../types'

const demoTone: Record<string, string> = {
  'internship-fee': 'demo-coral',
  'scholarship-fee': 'demo-amber',
  'bank-phishing': 'demo-red',
  'delivery-fee': 'demo-blue',
  'job-offer': 'demo-gold',
  'legitimate-internship': 'demo-green',
}

export default function DemoCenter({ busy, error, onAnalyze }: { busy: boolean; error: string; onAnalyze: (id: string) => void }) {
  const [cases, setCases] = useState<DemoCase[]>([])
  const [loadError, setLoadError] = useState('')

  useEffect(() => {
    getDemoCases().then(setCases).catch((caught: unknown) => setLoadError(caught instanceof Error ? caught.message : 'Demo cases could not be loaded.'))
  }, [])

  return (
    <div className="page-content demos-page">
      <div className="page-intro">
        <div><span className="section-kicker">FICTIONAL DATA · LIVE ANALYSIS</span><h1>Try the scenarios.</h1><p>Each case is invented for demonstration. Click one to run it through the live analysis pipeline.</p></div>
        <div className="demo-count"><BookOpenCheck size={17} /><strong>{cases.length.toString().padStart(2, '0')}</strong><span>DEMO CASES</span></div>
      </div>
      <div className="demo-banner"><span className="demo-banner-mark">FICTION</span><p>Every name, organization, domain, and offer below is fictional. These examples are not reports about real people or companies.</p><span className="demo-banner-end">DEMO ONLY</span></div>
      {loadError && <div className="form-error" role="alert">{loadError}</div>}
      {error && <div className="form-error" role="alert">{error}</div>}
      <div className="demo-grid">
        {cases.map((item, index) => <article className={`demo-card ${demoTone[item.id] ?? ''} reveal-in`} key={item.id} style={{ animationDelay: `${index * 55}ms` }}>
          <div className="demo-card-top"><span className="demo-type-mark">{item.id === 'legitimate-internship' ? <BadgeCheck size={17} /> : <ShieldAlert size={17} />}</span><span className="demo-fiction">FICTIONAL</span></div>
          <span className="demo-category">{item.category.toUpperCase()}</span>
          <h2>{item.title}</h2>
          <p>{item.description}</p>
          <div className="demo-quote">“{item.text.slice(0, 116)}{item.text.length > 116 ? '…' : ''}”</div>
          <button className="demo-run" onClick={() => onAnalyze(item.id)} disabled={busy}>{busy ? <><LoaderCircle className="spin" size={15} /> ANALYZING</> : <>RUN ANALYSIS <ArrowRight size={15} /></>}</button>
        </article>)}
      </div>
      <div className="demo-footer-note"><BookOpenCheck size={16} /><span>Demo analyses show results immediately and do not affect your dashboard history. Text is synthetic and does not contain real student data.</span></div>
    </div>
  )
}
