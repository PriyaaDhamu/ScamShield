import { useState } from 'react'
import { AlertTriangle, ArrowUpRight, Check, ChevronDown, CircleHelp, Fingerprint, ShieldAlert, ShieldCheck } from 'lucide-react'
import type { AnalysisResult, RiskLevel } from '../types'

const levelClass: Record<RiskLevel, string> = {
  'High Risk': 'risk-high',
  'Medium Risk': 'risk-medium',
  'Low Risk': 'risk-low',
  'Unable to Determine': 'risk-unknown',
}

export default function ResultReport({ result }: { result: AnalysisResult }) {
  const [showDetails, setShowDetails] = useState(false)
  const riskClass = levelClass[result.risk_level]
  const scoreColor = result.risk_level === 'High Risk' ? '#e76d5e' : result.risk_level === 'Medium Risk' ? '#e0a347' : result.risk_level === 'Low Risk' ? '#6da981' : '#959e93'

  return (
    <section className={`result-report ${riskClass}`} aria-live="polite">
      <div className="report-header">
        <div><span className="section-kicker">SECURITY ANALYSIS <i className="report-divider">/</i> {result.category.toUpperCase()}</span><h2>Here’s what we found.</h2></div>
        <span className="analysis-source">{result.source === 'demo' ? 'FICTIONAL DEMO' : result.source.toUpperCase()} <span>·</span> {new Date(result.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
      </div>

      <div className="score-overview">
        <div className="score-ring" style={{ '--score': `${result.risk_score * 3.6}deg`, '--score-color': scoreColor } as React.CSSProperties}>
          <div className="score-ring-inner"><strong>{result.risk_score}<small>/100</small></strong><span>RISK SCORE</span></div>
        </div>
        <div className="score-copy">
          <div className={`risk-level-label ${riskClass}`}><span className="risk-status-dot" />{result.risk_level.toUpperCase()}</div>
          <p>{result.summary}</p>
          <span className="confidence-note"><CircleHelp size={14} /> {result.confidence_note}</span>
        </div>
        <div className="report-signal-count"><strong>{result.evidence.length.toString().padStart(2, '0')}</strong><span>INDEPENDENT<br />SIGNALS</span></div>
      </div>

      <div className="report-columns">
        <div className="report-main-column">
          <section className="report-section evidence-section">
            <div className="report-section-title"><div><span className="section-kicker">THE EVIDENCE</span><h3>What stood out</h3></div><span className="evidence-total">{result.evidence.length} INDICATORS</span></div>
            {result.evidence.length ? <div className="evidence-list">{result.evidence.map((item, index) => <article className={`evidence-item evidence-${item.severity}`} key={`${item.key}-${index}`}>
              <div className="evidence-icon">{item.severity === 'high' ? <ShieldAlert size={17} /> : item.severity === 'medium' ? <AlertTriangle size={17} /> : <Fingerprint size={17} />}</div>
              <div className="evidence-copy"><div className="evidence-title-row"><strong>{item.title}</strong><span className={`severity-tag severity-${item.severity}`}>{item.severity}</span></div><p>{item.reason}</p>{item.quote && <blockquote>“{item.quote}”</blockquote>}</div>
              <div className="evidence-points">+{item.points}<small>PTS</small></div>
            </article>)}</div> : <div className="no-evidence"><ShieldCheck size={20} /><div><strong>No strong text indicators found</strong><span>That does not guarantee the sender or link is safe. Verify independently.</span></div></div>}
          </section>

          {result.url_checks.length > 0 && <section className="report-section url-evidence-section">
            <div className="report-section-title"><div><span className="section-kicker">LOCAL URL INSPECTION</span><h3>Destination signals</h3></div><span className="not-visited"><span /> NOT VISITED</span></div>
            {result.url_checks.map((check) => <div className="url-result-row" key={check.url}>
              <div className="url-result-address"><span className="url-favicon"><ArrowUpRight size={14} /></span><div><strong>{check.domain ?? check.url}</strong><span>{check.url}</span></div><span className="url-result-status">{check.status}</span></div>
              <ul className="url-features">{check.features.map((feature) => <li key={feature}>{feature}</li>)}</ul>
              <div className="reputation-note">{check.reputation}</div>
            </div>)}
          </section>}
        </div>

        <aside className="report-side-column">
          <section className="actions-section">
            <span className="section-kicker">YOUR NEXT MOVES</span><h3>Recommended actions</h3>
            <ol className="action-list">{result.actions.map((action, index) => <li key={action}><span>{String(index + 1).padStart(2, '0')}</span><p>{action}</p></li>)}</ol>
          </section>
          <details className="why-details" open={showDetails} onToggle={(event) => setShowDetails(event.currentTarget.open)}>
            <summary><span><CircleHelp size={16} /> Why did ScamShield say this?</span><ChevronDown size={16} /></summary>
            <div className="why-content">
              <p>The score combines separate, observable signals. A signal adds context; it does not prove fraud.</p>
              <div className="factor-list">{result.factors.length ? result.factors.map((factor, index) => <div className="factor-row" key={`${factor.label}-${index}`}><span>{factor.label}</span><strong>+{factor.points}</strong></div>) : <div className="factor-empty">No weighted signals contributed to this score.</div>}
                {result.model_probability != null && <div className="model-probability"><span>ML scam-pattern score</span><strong>{Math.round(result.model_probability * 100)}%</strong></div>}
              </div>
              <p className="model-caveat">{result.model_note} The ML signal is capped and combined with independent evidence; it is not a confidence rating.</p>
              <ul>{result.why.map((reason) => <li key={reason}>{reason}</li>)}</ul>
            </div>
          </details>
          <div className="report-safety-note"><AlertTriangle size={16} /><p><strong>Pause before acting.</strong> ScamShield can miss new tactics. Never treat a low score as proof of safety.</p></div>
        </aside>
      </div>
      <div className="report-bottom-line"><Check size={14} /><span>Analysis saved as a privacy-preserving dashboard summary. Message text is not stored.</span><span className="report-id">REF {result.id.slice(0, 8).toUpperCase()}</span></div>
    </section>
  )
}
