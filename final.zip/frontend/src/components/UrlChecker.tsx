import { useState } from 'react'
import { ArrowRight, CheckCircle2, CircleHelp, ExternalLink, Fingerprint, Globe2, LoaderCircle, ShieldAlert } from 'lucide-react'
import { checkUrl } from '../api'
import type { UrlCheck } from '../types'

export default function UrlChecker() {
  const [value, setValue] = useState('')
  const [result, setResult] = useState<UrlCheck | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!value.trim()) return
    setLoading(true)
    setError('')
    setResult(null)
    try {
      setResult(await checkUrl(value.trim()))
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'URL inspection failed.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="page-content url-page">
      <div className="page-intro">
        <div><span className="section-kicker">URL INTELLIGENCE</span><h1>Look at the address.</h1><p>Inspect visible URL structure without opening or following the link.</p></div>
        <div className="not-visited"><span /> LINK WILL NOT BE VISITED</div>
      </div>
      <div className="url-check-layout">
        <section className="url-check-form-panel">
          <div className="url-form-icon"><Globe2 size={20} /></div>
          <span className="section-kicker">LOCAL STRUCTURAL CHECK</span>
          <h2>Where does it really go?</h2>
          <p>Paste the complete link exactly as it appeared. ScamShield checks only the text of the address.</p>
          <form onSubmit={submit} className="url-input-form">
            <label className="visually-hidden" htmlFor="url-input">URL to inspect</label>
            <input id="url-input" type="url" value={value} onChange={(event) => setValue(event.target.value)} placeholder="https://example.com/path" maxLength={2048} required />
            <button className="button button-dark" type="submit" disabled={loading}>{loading ? <LoaderCircle className="spin" size={17} /> : <>Inspect URL <ArrowRight size={16} /></>}</button>
          </form>
          {error && <div className="form-error" role="alert">{error}</div>}
          <div className="url-rule-note"><CircleHelp size={15} /><span>A URL without HTTPS is not automatically malicious. Local reputation lookup is not configured.</span></div>
        </section>
        <aside className="url-method-panel">
          <span className="section-kicker">WHAT WE INSPECT</span>
          <div className="url-method-list">
            <div><span className="method-icon"><Fingerprint size={16} /></span><div><strong>Domain shape</strong><p>IP hosts, nested subdomains, punycode, and unusual characters.</p></div></div>
            <div><span className="method-icon"><ShieldAlert size={16} /></span><div><strong>Pressure patterns</strong><p>Trust-sensitive terms that appear inside the hostname.</p></div></div>
            <div><span className="method-icon"><ExternalLink size={16} /></span><div><strong>Destination visibility</strong><p>Long links and URL shorteners that obscure where a click lands.</p></div></div>
          </div>
          <div className="url-method-footer"><span className="method-status-dot" /> PASSIVE CHECK ONLY <span>·</span> NO NETWORK REQUESTS</div>
        </aside>
      </div>

      {result && <section className="standalone-url-result" aria-live="polite">
        <div className="url-result-heading"><div className={`url-result-symbol ${result.points ? 'url-symbol-alert' : ''}`}>{result.points ? <ShieldAlert size={20} /> : <CheckCircle2 size={20} />}</div><div><span className="section-kicker">INSPECTION RESULT</span><h2>{result.status}</h2></div><span className="url-score">+{result.points}<small> RISK PTS</small></span></div>
        <div className="standalone-address"><span>{result.domain ?? 'Unrecognized domain'}</span><code>{result.url}</code></div>
        <ul className="standalone-features">{result.features.map((feature) => <li key={feature}>{feature}</li>)}</ul>
        <div className="reputation-note">{result.reputation}</div>
        <div className="url-result-caveat"><CircleHelp size={15} /><p>This structural check cannot establish whether a site is safe. A clean result is not a guarantee. Verify the domain through an independently found official source.</p></div>
      </section>}
    </div>
  )
}
